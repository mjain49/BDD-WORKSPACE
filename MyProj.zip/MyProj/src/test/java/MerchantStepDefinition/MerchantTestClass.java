package MerchantStepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.MerchantPageFactory;
import pageBean.MerchantPageFactory;

public class MerchantTestClass{
	
	private WebDriver driver;
	private MerchantPageFactory mpf;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\softwares\\chromedriver_win32\\chromedriver.exe" );
		driver= new ChromeDriver();
		//driver=new FirefoxDriver();
	}
	@Given("^Merchant is on 'register' Page$")
	public void Merchant_is_on_register_Page() throws Throwable {
	    
		driver.get("D:\\BDD Workspace\\MyProj\\target\\Register.html");
		mpf = new MerchantPageFactory(driver);
		Thread.sleep(2000);
	}

	@When("^Merchant Enters Invalid Category$")
	public void Merchant_Enters_Invalid_Category() throws Throwable {
	    
		mpf.setCategory("");
		mpf.setRedirect();
	}

	@Then("^display 'Please Enter Valid Category'$")
	public void display_Please_Enter_Valid_Category() throws Throwable {
	    
		//System.out.println("Please Enter Valid Category");
	}

	@When("^Merchant Enters Valid Category and Category=\"([^\"]*)\"$")
	public void Merchant_Enters_Valid_Category_and_Category(String arg1) throws Throwable {
	    
		mpf.setCategory("Merchant");
		mpf.setRedirect();
	}

	@When("^Display 'merchant' page$")
	public void display_merchant_page() throws Throwable {
	    
		driver.get("D:\\BDD Workspace\\MyProj\\target\\Merchant.html");
		mpf = new MerchantPageFactory(driver);
		//Thread.sleep(2000);
	}

	@Given("^Merchant is on 'merchant' Page$")
	public void Merchant_is_on_merchant_Page() throws Throwable {
	    
		driver.get("D:\\BDD Workspace\\MyProj\\target\\Merchant.html");
		mpf = new MerchantPageFactory(driver);
	}

	@When("^Merchant Enters Invalid First Name$")
	public void Merchant_Enters_Invalid_First_Name() throws Throwable {
	    
	    mpf.setFname("");
	    mpf.setConfirmButton();
	}

	@Then("^display 'Please Enter Valid First Name'$")
	public void display_Please_Enter_Valid_First_Name() throws Throwable {
		String expectedMessage="Please fill the First Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Merchant Enters Invalid Last Name$")
	public void Merchant_Enters_Invalid_Last_Name() throws Throwable {
	    
		mpf.setFname("Mayur");
		mpf.setLname("");
	    mpf.setConfirmButton();
	}

	@Then("^display 'Please Enter Valid Last Name'$")
	public void display_Please_Enter_Valid_Last_Name() throws Throwable {
		String expectedMessage="Please fill the Last Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Merchant Enters Invalid Company Name$")
	public void Merchant_Enters_Invalid_Company_Name() throws Throwable {
	    
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("");
	    mpf.setConfirmButton();
	}

	@Then("^display 'Please Enter Valid Company Name'$")
	public void display_Please_Enter_Valid_Company_Name() throws Throwable {
		String expectedMessage="Please fill the Company Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Merchant Enters Invalid Mobile Number$")
	public void Merchant_Enters_Invalid_Mobile_Number() throws Throwable {
	    
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("Capgemini");
		mpf.setMobileno("");
	    mpf.setConfirmButton();
	}

	@Then("^display 'Please Enter Valid Mobile Number'$")
	public void display_Please_Enter_Valid_Mobile_Number() throws Throwable {
		String expectedMessage="Please fill the Mobile Number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^Merchant Enters Invalid EmailID$")
	public void Merchant_Enters_Invalid_EmailID() throws Throwable {
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("Capgemini");
		mpf.setMobileno("8652407781");
		mpf.setEmail("");
		mpf.setConfirmButton();
	}

	@Then("^display 'Please Enter Valid EmailID'$")
	public void display_Please_Enter_Valid_EmailID() throws Throwable {
		String expectedMessage="Please fill the Email";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@Given("^Merchant is on 'merchant' page$")
	public void Merchant_is_on_merchant_page() throws Throwable {
	    
		driver.get("D:\\BDD Workspace\\MyProj\\target\\Merchant.html");
		mpf = new MerchantPageFactory(driver);
		//Thread.sleep(2000);
	}

	@When("^Merchant Enters Invalid Password$")
	public void Merchant_Enters_Invalid_Password() throws Throwable {
	    
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("Capgemini");
		mpf.setMobileno("8652407781");
		mpf.setEmail("mayur1234@capgemini.com");
		mpf.setPassword("");
	    mpf.setConfirmButton();
	}

	@Then("^display 'Please Enter Valid Password'$")
	public void display_Please_Enter_Valid_Password() throws Throwable {
		String expectedMessage="Please fill the Password";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^Merchant Enters Invalid Confirm Password$")
	public void Merchant_Enters_Invalid_Confirm_Password() throws Throwable {
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("Capgemini");
		mpf.setMobileno("8652407781");
		mpf.setEmail("mayur1234@capgemini.com");
		mpf.setPassword("Asdf@1234");
		mpf.setConfirmpassword("");
		mpf.setConfirmButton(); 
	}


	@Then("^display 'Please Enter Valid ConfirmPassword'$")
	public void display_Please_Enter_Valid_ConfirmPassword() throws Throwable {
		String expectedMessage="Please fill the Confirm Password / Check whether both confirm password and password are same";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Merchant Enters Invalid Answer for SecrityQuestion one$")
	public void Merchant_Enters_Invalid_Answer_for_SecrityQuestion_one() throws Throwable {
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("Capgemini");
		mpf.setMobileno("8652407781");
		mpf.setEmail("mayur1234@capgemini.com");
		mpf.setPassword("Asdf@1234");
		mpf.setConfirmpassword("Asdf@1234");
		mpf.setFsq("");
		mpf.setConfirmButton(); 
	}

	@Then("^display 'Please Enter Valid Answer for SecrityQuestion one'$")
	public void display_Please_Enter_Valid_Answer_for_SecrityQuestion_one() throws Throwable {
		String expectedMessage="Please fill the answer for Security Question one";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Merchant Enters Invalid Answer for SecrityQuestion two$")
	public void Merchant_Enters_Invalid_Answer_for_SecrityQuestion_two() throws Throwable {
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("Capgemini");
		mpf.setMobileno("8652407781");
		mpf.setEmail("mayur1234@capgemini.com");
		mpf.setPassword("Asdf@1234");
		mpf.setConfirmpassword("Asdf@1234");
		mpf.setFsq("Mumbai");
		mpf.setSsq("");
		mpf.setConfirmButton();
	}

	@Then("^display 'Please Enter Valid Answer for SecrityQuestion two'$")
	public void display_Please_Enter_Valid_Answer_for_SecrityQuestion_two() throws Throwable {
		String expectedMessage="Please fill the answer for Security Question two";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^Merchant clicks on Create Account$")
	public void Merchant_clicks_on_Create_Account() throws Throwable {
	    
		mpf.setFname("Mayur");
		mpf.setLname("Jain");
		mpf.setCname("Capgemini");
		mpf.setMobileno("8652407781");
		mpf.setEmail("mayur1234@capgemini.com");
		mpf.setPassword("Asdf@1234");
		mpf.setConfirmpassword("Asdf@1234");
		mpf.setFsq("Mumbai");
		mpf.setSsq("Ram");
		mpf.setConfirmButton(); 
	}

	@Then("^display 'success' Page$")
	public void display_Yoursuccess_Page() throws Throwable {
		String expectedMessage="Successful!!!!";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.get("D:\\BDD Workspace\\MyProj\\target\\success.html");  
	}


}
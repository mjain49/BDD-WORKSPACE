package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {

	@Given("^User will select Products$")
	public void user_will_select_Products() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("Select Product");
	}

	@Given("^User will Add Products to Cart$")
	public void user_will_Add_Products_to_Cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("Add Product");
	}

	@When("^User clicks on show cart$")
	public void user_clicks_on_show_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("Show Product");
	}

	@Then("^Show the list of products to user from cart$")
	public void show_the_list_of_products_to_user_from_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("List of Product");
	}
}

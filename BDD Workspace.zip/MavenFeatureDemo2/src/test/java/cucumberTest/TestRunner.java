package cucumberTest;



import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"src/test/java/showProduct"},glue= {"stepDefinition"},format= {"pretty"},dryRun= true)
//@CucumberOptions(features= {"src/test/java/showProduct"},glue= {"stepDefinition"},format= {"pretty"},dryRun= false) //Bydefault dry Run is false so no need to specify anything 
//@CucumberOptions(features= {"src/test/java/showProduct"},glue= {"/test/java/stepDefinition"},format= {"html:D:\\BDD Workspace"})
//@CucumberOptions(features= {"src/test/java/showProduct"},glue= {"/test/java/stepDefinition"},format= {"json:D:\\BDD Workspace/cucumber.json"})
public class TestRunner {

}

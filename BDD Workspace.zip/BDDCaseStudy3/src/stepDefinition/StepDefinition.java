package stepDefinition;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	
	@After
	public void after() {
		System.out.println("After Method");
	}
	
	@Before
	public void before() {
		System.out.println("Before Method");
		System.out.println("==========================================================================");
	}
	
	@Given("^i have two numbers$")
	public void i_have_two_numbers() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Have two Numbers");
	}

	@When("^I add \"([^\"]*)\" the numbers$")
	public void i_add_the_numbers(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Scenario 1 Addition");
	}

	@Then("^Number Should be Added$")
	public void number_Should_be_Added() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Both Number Should be Added");
	}

	@Given("^there is third number$")
	public void there_is_third_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Scenario 2 Addition");
	}

	@Then("^check the result$")
	public void check_the_result() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("All Thress Numbers Should be Added");
	}
	

}

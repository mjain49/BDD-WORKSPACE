package stepDefinition;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestClass {

	
	@Given("^User will enter <username> and click on button$")
	public void user_will_enter_username_and_click_on_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User will enter username and click on button");
	}

	@When("^User will Click show alert box button$")
	public void user_will_Click_show_alert_box_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User will click show alert box button");
	}

	@Then("^Message will Display \"([^\"]*)\"$")
	public void message_will_Display(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("Message will display:-Hello! I am an alert box! ");
	}
}
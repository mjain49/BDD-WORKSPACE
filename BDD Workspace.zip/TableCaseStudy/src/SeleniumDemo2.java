import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class SeleniumDemo2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/html/3.html");
		WebElement element1 = driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[1]/input"));
		element1.sendKeys("Mayur");
		WebElement element2 = driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]/input"));
		element2.sendKeys("21");
		WebElement element3 = driver.findElement(By.xpath("/html/body/table/tbody/tr[3]/td[1]/input"));
		element3.sendKeys("Krish");
		WebElement element4 = driver.findElement(By.xpath("/html/body/table/tbody/tr[3]/td[2]/input"));
		element4.sendKeys("22");
		Thread.sleep(100000);
		driver.quit();
	}

}

package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserPageFactory {

	//Driver
	WebDriver driver;
	
	//Initialization
	public UserPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
//	
//	@FindBy(xpath="/html/head/title")
//	@CacheLookup
//	WebElement title;
	
	
	//Full Name
	@FindBy(name="txtNM")
	@CacheLookup
	WebElement name;
	

	//Name on the pan card
	@FindBy(name="txtFName")
	@CacheLookup
	WebElement fname;
	
	@FindBy(name="txtLName")
	@CacheLookup
	WebElement lname;
	
	@FindBy(name="txtFtName")
	@CacheLookup
	WebElement ftname;
	
	@FindBy(name="txtDOB")
	@CacheLookup
	WebElement dob;
	
	//GENDER
	
	@FindBy(id="rdbMale")
	@CacheLookup
	WebElement rdbMale;
	@FindBy(id="rdbFemale")
	@CacheLookup
	WebElement rdbFemale;
	
	@FindBy(name="txtMNo")
	@CacheLookup
	WebElement mnumber;
	
	@FindBy(name="txtEmailID")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="txtLLine")
	@CacheLookup
	WebElement lnumber;
	
	//Communication
	@FindBy(id="rdbResAddress")
	@CacheLookup
	WebElement radd;
	
	@FindBy(id="rdbOfficeAdd")
	@CacheLookup
	WebElement offadd;
	
	@FindBy(id="txtAResidenceAdd")
	@CacheLookup
	WebElement raddress;
	
	@FindBy(id="btnSubmit")
	@CacheLookup
	WebElement btnSubmit;
	
//	@FindBy(id="btnReset")
//	@CacheLookup
//	WebElement btnReset;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

//	public WebElement getTitle() {
//		return title;
//	}
//
//	public void setTitle(String title) {
//		this.title.sendKeys(title);;
//	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public WebElement getFtname() {
		return ftname;
	}

	public void setFtname(String ftname) {
		this.ftname.sendKeys(ftname);
	}

	public WebElement getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob.sendKeys(dob);
	}

	public WebElement getRdbMale() {
		return rdbMale;
	}

	public void setRdbMale() {
		this.rdbMale.click();
	}

	public WebElement getRdbFemale() {
		return rdbFemale;
	}

	public void setRdbFemale() {
		this.rdbFemale.click();
	}

	public WebElement getMnumber() {
		return mnumber;
	}

	public void setMnumber(String mnumber) {
		this.mnumber.sendKeys(mnumber);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getLnumber() {
		return lnumber;
	}

	public void setLnumber(String lnumber) {
		this.lnumber.sendKeys(lnumber);
	}

	public WebElement getRadd() {
		return radd;
	}

	public void setRadd() {
		this.radd.click();
	}

	public WebElement getOffadd() {
		return offadd;
	}

	public void setOffadd() {
		this.offadd.click();
	}

	public WebElement getRaddress() {
		return raddress;
	}

	public void setRaddress(String raddress) {
		this.raddress.sendKeys(raddress);
	}

	public WebElement getBtnSubmit() {
		return btnSubmit;
	}

	public void setBtnSubmit() {
		this.btnSubmit.click();
	}

	
	
	
	
}

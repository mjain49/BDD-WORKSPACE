package payment;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.PaymentPageFactory;

public class PaymentStepDefinition {

	private WebDriver driver;
	private PaymentPageFactory ppf;
	
	
	//Initialize the Chrome Driver 
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
	}

	
	@Given("^User is on the 'Payment Details' Page$")
	public void user_is_on_the_Payment_Details_Page() throws Throwable {
		driver.get("D:\\BDD Workspace\\TestBDD\\target\\PaymentDetails.html");
	    ppf =new PaymentPageFactory(driver);
	    Thread.sleep(2000);
	}
	
	
	@When("^User view it on the chrome browser$")
	public void user_view_it_on_the_chrome_browser() throws Throwable {
		String expectedMessage="Payment Details";
		String actualMessage=driver.getTitle();
		System.out.println(actualMessage);
		Assert.assertEquals(expectedMessage, actualMessage);
		
		//driver.close();
	}

	@Then("^The title of the page should be 'Personal Details'$")
	public void the_title_of_the_page_should_be_Personal_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		  System.out.println("Title Verified");
	}
	
	
	@Given("^user is on 'Payment Details' page$")
	public void user_is_on_Payment_Details_page() throws Throwable {
		driver.get("D:\\BDD Workspace\\TestBDD\\target\\PaymentDetails.html");
	    ppf =new PaymentPageFactory(driver);
	    Thread.sleep(2000);
	}
	
	@When("^user enters invalid CardHolder name$")
	public void user_enters_invalid_CardHolder_name() throws Throwable {
	ppf.setChname("");
	ppf.setBtnPayment();
	}

	@Then("^displays 'Please fill the CardHolder Name'$")
	public void displays_Please_fill_the_CardHolder_Name() throws Throwable {
	System.out.println("Please fill the CardHolder Name");   
	}

	@When("^user enters invalid Debit Card Number$")
	public void user_enters_invalid_Debit_Card_Number() throws Throwable {
	ppf.setChname("Mj");
	ppf.setDebitnum("");
	ppf.setBtnPayment();	   
	}

	@Then("^displays 'Please fill the Debit Card Number'$")
	public void displays_Please_fill_the_Debit_Card_Number() throws Throwable {
	System.out.println("Please fill the Debit Card Number");   
	}

	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month() throws Throwable {
	ppf.setChname("Mj");
	ppf.setDebitnum("123456789");
	ppf.setCvv("123");
	ppf.setMonth("");
	ppf.setBtnPayment();    
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() throws Throwable {
	System.out.println("Please fill expiration month");    
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() throws Throwable {
	ppf.setChname("Mj");
	ppf.setDebitnum("123456789");
	ppf.setCvv("123");
	ppf.setMonth("April");
	ppf.setYear("");
	ppf.setBtnPayment();   
	}

	@Then("^displays 'Please fill expiration year'$")
	public void displays_Please_fill_expiration_year() throws Throwable {
	System.out.println("Please fill expiration year");   
	}

	@When("^user enters valid payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
	ppf.setChname("Mj");
	ppf.setDebitnum("123456789");
	ppf.setCvv("123");
	ppf.setMonth("April");
	ppf.setYear("2020");
	ppf.setBtnPayment();    
	}

	@Then("^displays 'Pan Card Registration Done Successfully!!!'$")
	public void displays_Pan_Card_Registration_Done_Successfully() throws Throwable {
	String expectedMessage="Pan Card Registration Done successfully !!!â€�";
	String actualMessage=driver.switchTo().alert().getText();
	Assert.assertEquals(expectedMessage, actualMessage);
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	//driver.close();
	}
}

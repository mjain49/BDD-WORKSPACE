package user;

import java.sql.Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.UserPageFactory;

public class UserStepDefinition {

	private WebDriver driver;
	private UserPageFactory upf;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@When("^User view it on the chrome browser$")
	public void user_view_it_on_the_chrome_browser() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedMessage = "PAN CARD: User Information";
		String actualMessage = driver.getTitle();
		System.out.println(actualMessage);
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@Then("^The title of the page should be 'PAN CARD: User Information'$")
	public void the_title_of_the_page_should_be_PAN_CARD_User_Information() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Title Verified");
	}

	@Given("^User is on the 'UserInformation' Page$")
	public void user_is_on_the_UserInformation_Page() throws Throwable {
		driver.get("D:\\BDD Workspace\\TestBDD\\target\\UserInformation.html");
		upf = new UserPageFactory(driver);
		Thread.sleep(2000);
	}

	@When("^User enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
		upf.setName("");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please fill the Applicant Name'$")
	public void display_Please_fill_the_Applicant_Name() throws Throwable {
		String expectedMessage = "Please fill the Applicant Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		String expectedMessage = "Please fill the First Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage = "Please fill the Last Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid father name$")
	public void user_enters_invalid_father_name() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please fill the Father Name'$")
	public void display_Please_fill_the_Father_Name() throws Throwable {
		String expectedMessage = "Please fill the Father Name ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid DOB$")
	public void user_enters_invalid_DOB() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please enter date of birth'$")
	public void display_Please_enter_date_of_birth() throws Throwable {
		String expectedMessage = "Please fill the DOB";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// @When("^User enters invalid DOB$")
	// public void user_enters_invalid_DOB2() throws Throwable {
	// upf.setName("Mayur Laxmilal Jain");
	// upf.setFname("Mayur");
	// upf.setLname("Jain");
	// upf.setFtname("Laxmilal");
	// upf.setDob("07041998");
	// upf.setBtnSubmit();
	// }
	//
	@Then("^display 'Please Enter valid date\\(dd-MM-yyyy\\)'$")
	public void display_Please_Enter_valid_date_dd_MM_yyyy() throws Throwable {
		String expectedMessage = "Please fill the DOB";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid gender$")
	public void user_enters_invalid_gender() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("07-04-1998");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please select the Gender'$")
	public void display_Please_select_the_Gender() throws Throwable {
		String expectedMessage = "Please select the Gender";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid mobile no$")
	public void user_enters_invalid_mobile_no() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("07-04-1998");
		upf.setRdbMale();
		upf.setMnumber("");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please fill the Mobile no'$")
	public void display_Please_fill_the_Mobile_no() throws Throwable {
		String expectedMessage = "Please fill Mobile no";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	// @When("^User enters invalid mobile no$")
	// public void user_enters_invalid_mobile_no2() throws Throwable {
	// upf.setName("Mayur Laxmilal Jain");
	// upf.setFname("Mayur");
	// upf.setLname("Jain");
	// upf.setFtname("Laxmilal");
	// upf.setDob("07-04-1998");
	// upf.setRdbMale();
	// upf.setMnumber("");
	// upf.setBtnSubmit();
	// }

	@Then("^display 'Please fill (\\d+) digit Mobile no'$")
	public void display_Please_fill_digit_Mobile_no(int arg1) throws Throwable {
		String expectedMessage = "Please fill Mobile no";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid email id$")
	public void user_enters_invalid_email_id() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("07-04-1998");
		upf.setRdbMale();
		upf.setMnumber("8652407781");
		upf.setEmail("");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please fill the MailId id'$")
	public void display_Please_fill_the_MailId_id() throws Throwable {
		String expectedMessage = "Please fill the Email id ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid landline$")
	public void user_enters_invalid_landline() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("07-04-1998");
		upf.setRdbMale();
		upf.setMnumber("8652407781");
		upf.setEmail("mayur-laxmilal.jain@capgemini.com");
		upf.setLnumber("");
		upf.setBtnSubmit();
	}

	@Then("^display 'please fill the landline no'$")
	public void display_please_fill_the_landline_no() throws Throwable {
		String expectedMessage = "please fill the landline no";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid communication$")
	public void user_enters_invalid_communication() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("07-04-1998");
		upf.setRdbMale();
		upf.setMnumber("8652407781");
		upf.setEmail("mayur-laxmilal.jain@capgemini.com");
		upf.setLnumber("23145678");
		upf.setBtnSubmit();
	}

	@Then("^display 'Please select Communication '$")
	public void display_Please_select_Communication() throws Throwable {
		String expectedMessage = "Please select the Type of Communication ";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters invalid residence address$")
	public void user_enters_invalid_residence_address() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("07-04-1998");
		upf.setRdbMale();
		upf.setMnumber("8652407781");
		upf.setEmail("mayur-laxmilal.jain@capgemini.com");
		upf.setLnumber("23145678");
		upf.setOffadd();
		upf.setRaddress("");
		upf.setBtnSubmit();
	}

	@Then("^display 'please enter the Addresss'$")
	public void display_please_enter_the_Addresss() throws Throwable {
		String expectedMessage = "please enter the Addresss";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^User enters valid details residence address$")
	public void user_enters_valid_details_residence_address() throws Throwable {
		upf.setName("Mayur Laxmilal Jain");
		upf.setFname("Mayur");
		upf.setLname("Jain");
		upf.setFtname("Laxmilal");
		upf.setDob("07-04-1998");
		upf.setRdbMale();
		upf.setMnumber("8652407781");
		upf.setEmail("mayur-laxmilal.jain@capgemini.com");
		upf.setLnumber("23145678");
		upf.setOffadd();
		upf.setRaddress("Capgemini Hinjewadi Pune");
		upf.setBtnSubmit();
	}

	@Then("^alert display 'Personal details are validated\\.'$")
	public void alert_display_Personal_details_are_validated() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String expectedMessage = "Personal details are validated.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
	}

	@Then("^The user is navigated to the 'PaymentDetails\\.html' page$")
	public void the_user_is_navigated_to_the_PaymentDetails_html_page() throws Throwable {
		// String expectedMessage="Personal details are validated.";
		// String actualMessage=driver.switchTo().alert().getText();
		// Assert.assertEquals(expectedMessage, actualMessage);
		// driver.switchTo().alert().accept();
		// driver.close();
		driver.navigate().to("D:\\BDD Workspace\\TestBDD\\target\\PaymentDetails.html");
	}
}
